<!DOCTYPE html>
<HTML lang="en">
    <head>
        <link rel="stylesheet" href="registration.css">
        <title>SIGN UP</title>
       
    </head>
+
    <body>
    <form action="register_client.php" method="POST">
        <div class="box-form">
            <div class="left">
                <div class="overlay">
                <h1>Aaliyah</h1>
                <p>MODERN HIJABS</p>
               
                </div>
            </div>
            
            
                <div class="right">
                <h5>SIGN UP </h5>
               
                <div class="inputs"> 
                    <input type="text" id="first_name" name="first_name" placeholder="First Name">
                    
                    <input type="text" id="surname"    name="surname" placeholder="Surname">
                    
                    <input type="text" id= "email" name="email" placeholder="Email">
                    <br>
                    <input type="password"  id="password" name="password" placeholder="Password">
                    
                    
                </div>
                <div class="button">
          <input type="submit" value="Register">
        </div>  
                    
            </div>
            
        </div>
        <!-- partial -->
</form>

</body>
</HTML>