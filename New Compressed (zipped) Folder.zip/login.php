<html>
    
 

<link rel="stylesheet" href="style.css">
<form action='login.php' method='post'>
    <input type='text' name='username'placeholder='username'>
    <input type='text' name='password'placeholder='password'>

    <input type='submit' name='login'value='login'>
</form>
<a href='index.php?edit=1'></a>
</html>